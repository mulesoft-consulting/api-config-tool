package org.toilelibre.libe.curl;
public final class Version {
 public static String VERSION = "0.0.19";
 public static String BUILD_TIME = "2018-09-28T20:40:17Z";
}
